#include "header.h"

CAN1 r;
u8 f=0;

int main()
{
	float vout,tempr;
	u32 result;
	char s[20],s1[20];
	can_init();
	lcd_init();
	lcd_cgram();
	can_config();
	uart_init(9600);
	 lcd_data(0);
	while(1)
	{
//	uart_tx_str("before");
		if(f==1)
		{
			f=0;
			//uart_tx_str("init\r\n");
    	switch(r.byteA&0xff)
	    {
				case 0x10:
					lcd_cmd(0xc0);
				uart_tx_str("head light ON\r\n");
					lcd_data(3);
				break;
				case 0x11:
				  lcd_cmd(0xc0);
				uart_tx_str("head light OFF\r\n");
				  lcd_data(2);
				break;
				case 0x20:
					lcd_cmd(0xc5);
				uart_tx_str("left indicator ON\r\n");
				lcd_data(1);
				break;
				case 0x21:
					lcd_cmd(0xc5);
				uart_tx_str("left indicator OFF\r\n");
				lcd_data(2);
				break;
				case 0x30:
					uart_tx_str("right indicator ON\r\n");
					lcd_cmd(0xca);
				lcd_data(0);
				break;
				case 0x31:
					uart_tx_str("right indicator OFF\r\n");
					lcd_cmd(0xca);
				lcd_data(2);
				break;
				case 0x3:
					result=r.byteB;
				result=result*150;
				result=result/1023;
				uart_tx_str("speed : ");
				uart_tx_int(result);
				uart_tx_str("\r\n");
				sprintf(s1,"%d",result);
				lcd_cmd(0x88);
				lcd_str("     ");
				lcd_cmd(0x88);
				lcd_str(s1); 
				break;
	      case 0x4:
					result=r.byteB;
				  vout=(result*3.3);
				vout=vout/1023;
	        tempr=(vout-0.5)/0.01;
				//tempr=vout/0.1;
				uart_tx_str("temp : ");
				result=tempr;
	        sprintf(s,"%d",result);
				uart_tx_str(s);
				uart_tx_str("\r\n");
				lcd_cmd(0x80);
				lcd_str("       ");
				lcd_cmd(0x80);
				lcd_str(s);
				break;
				default: uart_tx_str("deault\r\n");
	    }
	}
}
	
}
