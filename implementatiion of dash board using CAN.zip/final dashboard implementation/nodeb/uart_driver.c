#include<lpc21xx.h>
#include "header.h"
char ch,s3=0;
//initialization...................
void uart_init(u32 baud)
{
	char a[]={15,60,30,15,15};
	u32 result,pclk;
	pclk=a[VPBDIV]*1000000;
	result=pclk/(16*baud);
	PINSEL0|=0x05;
	U0LCR=0x83;
	U0DLL=(result&0xff);
	U0DLM=((result>>8)&0xff);
	U0LCR=0x03;
}

//transmit a char...................
void uart_tx(u8 data)
{
	U0THR=data;
	while(THRE==0);
}

//receive a char..................
u8 uart_rx(void)
{
 while(RDR==0);
	return U0RBR;
}

// transmit a string...............

void uart_tx_str(char *p)
{
	while(*p)
	{
	  U0THR=*p;
		while(THRE==0);
		p++;
	}
}

//receive a string.....................................................
void uart_rx_str(char *p,u8 len)
{
	u8 i;
	for(i=0;i<len;i++)
	{
		while(RDR==0);
		p[i]=U0RBR;
		if(p[i]=='\r')
			break;
	}	
	p[i]='\0';
}

// number transmit........

void uart_tx_int(u32  n)
{
	u8 a[10];
	int i=0;
	
	do
	{
	a[i++]=n%10;
	n=n/10;
	}while(n);
	
	for(i=i-1;i>=0;i--)
	uart_tx(a[i]+48);
}

 /*
//password check...........
int password_check()
{
char a[]="1234",b[10];
	u8 temp;
	uart_init(9600);
	uart_tx_str("enter password....\r\n");
  uart_rx_str(b,9);
  uart_tx_str("1.password show \r\n 2.dont show\r\n");
	temp=uart_rx();
  if(temp=='1')
		uart_tx_str(b);
	if(my_strcmp(a,b)!=0)
	{
  uart_tx_str("wrong password..\r\n");
		return 0;
	}
	else
	{
		uart_tx_str("correct \r\n");
		return 1;
	}
}
*/

int my_strcmp(s8 *a,s8 *b)
{
	u8 i;
	for(i=0;a[i];i++)
	{
	if(a[i]!=b[i])
		return a[i]-b[i];
	}
	return 0;
}


void uart_tx_float(float num)
{
	//num=num*100;
  int n=(int)num,i;
	char a[13];
  uart_tx_int(n);
	uart_tx('.');
	num=num*100;
	n=(int)num;
	while(n)
	{
	if(n%10)
	{
		for(i=0;i<2;i++,n/=10)
		a[i]=n%10+48;
		for(i=i-1;i>=0;i--)
		uart_tx(a[i]);
		n=0;
	}
		n=n/10;
	}

}
	
	
/*
void extint_config(void)
{
	VICIntSelect=0;
	VICVectCntl0=6|1<<5;
	VICVectAddr0=(unsigned int)uart_handler;
	U0IER=1;
	VICIntEnable|=1<<6;
}

void uart_handler(void)__irq{
	char r=U0IIR;
	if((r&0x0e)==4)
	{
		ch=U0RBR;
	}
	VICVectAddr=0;
}


  */




