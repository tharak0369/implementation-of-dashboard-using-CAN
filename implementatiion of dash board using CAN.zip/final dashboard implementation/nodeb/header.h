#include<lpc21xx.h>
#include<stdio.h>
typedef unsigned char u8;
typedef unsigned int u32;
typedef signed char s8;

#define THRE ((U0LSR>>5)&1)
#define RDR (U0LSR&1)

typedef struct nodeB   //struct typedef
{
	u32 id;
	u32 byteA;
	u32 byteB;
	u8 rtr;
	u8 dlc;
}CAN1;



void can_init(void);     //can
void can_config(void);
void can1_handler(void)__irq;


void lcd_data(u8 data);    // lcd
void lcd_cmd(u8 cmd);
void lcd_init(void);
void delay_ms(u32 ms);
void lcd_str(char *p);
void lcd_cgram(void);       //cgram

void uart_init(u32 baud);
void uart_tx_str(char*p);
void uart_tx_int(u32  n);

