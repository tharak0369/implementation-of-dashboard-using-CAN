#include "header.h"
extern CAN1 r;
extern u8 f;

void can_init(void)
{
VPBDIV=1;
PINSEL1|=0x14000;
C2MOD=1;	
C2BTR=0X001c001d;
AFMR=2;
C2MOD=0;	
}

void can_config(void)
{
VICIntSelect=0;
VICVectAddr0=(unsigned int)can1_handler;
VICVectCntl0=27|1<<5;
VICIntEnable=(1<<27);
C2IER=1;
}

void can1_handler(void)__irq
{	
	f=1;
	r.id=C2RID;
	r.rtr=((C2RFS>>30)&1);
	r.dlc=((C2RFS>>16)&0XF);
	r.byteA=C2RDA;
	r.byteB=C2RDB;
	
	C2CMR=(1<<2);
	VICVectAddr=0;
}





