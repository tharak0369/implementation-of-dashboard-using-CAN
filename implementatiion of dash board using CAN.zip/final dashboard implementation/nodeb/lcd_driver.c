#include<lpc21xx.h>
#include "header.h"

unsigned char a[]={0x0,0x04,0x06,0x1f,0x06,0x04,0x0,0x0,
	                 0x0,0x04,0x0c,0x1f,0x0c,0x04,0x0,0x0,
								   0x0,0x0,0x0,0x0,0x0,0x0,0x00,0x0,
				           0x0,0x14,0x06,0x17,0x06,0x14,0x00,0x0};

///data...............

void lcd_data(unsigned char data)
{
unsigned int temp;
//higher
IOCLR1=0xfe<<16;
temp=(data&0xf0)<<16;
IOSET1=temp;
IOSET1=1<<17;
IOCLR1=1<<18;
IOSET1=1<<19;
delay_ms(2);
IOCLR1=1<<19;

//lower
IOCLR1=0xfe<<16;
temp=(data&0x0f)<<20;
IOSET1=temp;
IOSET1=1<<17;
IOCLR1=1<<18;
IOSET1=1<<19;
delay_ms(2);
IOCLR1=1<<19;
}

void lcd_cmd(unsigned char cmd)
{
unsigned int temp;
IOCLR1=0xfe<<16;
temp=(cmd&0xf0)<<16;
IOSET1=temp;
IOCLR1=1<<17;
IOCLR1=1<<18;
IOSET1=1<<19;
delay_ms(2);
IOCLR1=1<<19;


//lower
IOCLR1=0xfe<<16;
temp=(cmd&0x0f)<<20;
IOSET1=temp;
IOCLR1=1<<17;
IOCLR1=1<<18;
IOSET1=1<<19;
delay_ms(2);
IOCLR1=1<<19;
}

void lcd_init(void)
{
IODIR1=0xfe<<16;
IOCLR1=1<<19;
PINSEL2=0x0;
lcd_cmd(0x02);
lcd_cmd(0x28);
lcd_cmd(0x0e);
lcd_cmd(0x01);
lcd_cmd(0x0f);
}

void lcd_str(char *p)
{
	while(*p)
	{
	lcd_data(*p);
	p++;
	}
}


void lcd_cgram(void)
{
	int i;
	lcd_cmd(0x40);
	for(i=0;i<32;i++)
	lcd_data(a[i]);
	lcd_cmd(0x80);	
}

void delay_ms(u32 ms)
{
	T0PC=0;
	T0PR=60000-1;
	T0TC=0;
	T0TCR=1;
	while(T0TC<ms);
	T0TCR=0;
}
