#include "header.h"
#include<lpc21xx.h>
char f=0,c=0,f1=0;
void can_init(void)
{
VPBDIV=1;
PINSEL1|=0x14000;
C2MOD=1;	
C2BTR=0X001c001d;
AFMR=2;
C2MOD=0;	
}
void can_tx(CAN1 v)
{
C2TID1=v.id;	
C2TFI1=v.dlc<<16;
if(v.rtr==0)
{	
	C2TDA1=v.byteA;
	C2TDB1=v.byteB;
}
else
	C2TFI1|=(1<<30); 
	C2CMR=1|(1<<5);
while(((C2GSR>>3)&1)==0);
}

void timer1_config(void)
{
//	T1TCR=0X02;
	T1TC=0;
	T1PC=0;
	T1PR=60000-1;
	T1MR0=500;
	T1MCR=0X03;
	T1TCR=0X01;
	VICIntSelect=0;
	VICVectAddr0=(unsigned int)timer1_handler;
	VICVectCntl0=5|1<<5;
	VICIntEnable|=1<<5;
}
void timer1_handler(void)__irq
{
	f=1;
	c=c+25;
	if(c==100)
	{
		f1=1;
		c=0;
	}
	T1IR=0X01;
	VICVectAddr=0;
}

