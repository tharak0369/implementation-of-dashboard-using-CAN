#include "header.h"
extern char f,f1;
int main()
{
	CAN1 h,l,r,t,s;
	u8 s1=0,s2=0,s3=0;
	can_init();
	adc_init();
	uart_init(9600);
	timer1_config();
	h.id=0x120;
	h.rtr=0;
	h.dlc=1;
	h.byteB=0;
	l.id=0x121;
	l.rtr=0;
	l.dlc=1;
	l.byteB=0;
	r.id=0x122;
	r.rtr=0;
	r.dlc=1;
	r.byteB=0;
	t.id=0x123;
	t.rtr=0;
	t.dlc=8;
	s.id=0x124;
	s.rtr=0;
	s.dlc=8;
	while(1)
	{
	if(SW1==0)     //sw1=headlight
	{
		s1=s1^1<<0;
	while(SW1==0);
	if(s1)
	h.byteA=0x10;
  else
		h.byteA=0x11;
	can_tx(h);
	}
	
	if(SW2==0)    //sw2=left indicator
	{
		s2=s2^1<<0;
	while(SW2==0);
	if(s2)
	l.byteA=0x20;
  else
		l.byteA=0x21;
	can_tx(l);
	}
	
	
	if(SW3==0)    //sw3=right indicator
	{
		s3=s3^1<<0;
	while(SW3==0);
	if(s3)
	r.byteA=0x30;
  else
	r.byteA=0x31;
	can_tx(r);
	}
	
	if(f==1)
	{
			uart_tx('a');
		s.byteB=adc_read(2);
		s.byteA=0x3;
		can_tx(s);
		f=0;
	}
	
	if(f1==1)
	{
		uart_tx('b');
		t.byteB=adc_read(1);
		t.byteA=0x4;
		can_tx(t);
		f1=0;
		uart_tx('d');
	}
}
}
