#include "header.h"

void adc_init(void)
{
	PINSEL1|=0X15400000;
	ADCR=0X00201000;
}

 u32 adc_read(u8 ch_num)
{
	u32 result;
	ADCR|=(1<<ch_num);
	ADCR|=1<<24;
//	uart_tx('c');
	while(((ADDR>>31)&1)==0);
	ADCR^=(1<<ch_num);
	ADCR^=1<<24;
	result=((ADDR>>6)&0x3ff);
	return result;
}
