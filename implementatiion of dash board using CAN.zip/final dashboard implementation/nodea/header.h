#include<lpc21xx.h>

typedef unsigned char u8;
typedef unsigned int u32;

typedef struct nodeA   //struct typedef
{
	u32 id;
	u32 byteA;
	u32 byteB;
	u8 rtr;
	u8 dlc;
}CAN1;

#define SW1 ((IOPIN0>>14)&1)  //switches
#define SW2 ((IOPIN0>>15)&1)
#define SW3 ((IOPIN0>>16)&1)

void can_init(void);  //can
void can_tx(CAN1 v);

u32 adc_read(u8 ch_num);  //adc
void adc_init(void);

void timer1_config(void); //timer
void timer1_handler(void)__irq;

void uart_init(u32 baud);
void uart_tx(u8 data);
